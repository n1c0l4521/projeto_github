# Análise de Logs

Este projeto realiza uma análise automatizada de arquivos de log em formato CSV, com o objetivo de gerar insights estatísticos e gráficos a partir dos dados fornecidos.

## Funcionalidades Principais

- Leitura e processamento de arquivos CSV contendo logs
- Análise estatística de colunas específicas
- Geração de gráficos para visualização de padrões
- Exportação de relatórios (se aplicável)

## Instalação

Clone este repositório e instale as dependências:

```bash
git clone <url-do-repositorio>
cd projeto_github
pip install -r requirements.txt
```

## Como Usar

Coloque seu arquivo de log no formato `.csv` na raiz do projeto e execute:

```bash
python analise_logs10.py
```

## Autores

- Nome do Autor 1
- Nome do Autor 2
